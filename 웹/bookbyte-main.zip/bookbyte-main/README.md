# bookbyte

【python version】
3.12.3

【installed lists】
pip install django
pip install pillow
pip install django-bootstrap4

conda install -c conda-forge scikit-surprise
pip install pandas

pip install requests
